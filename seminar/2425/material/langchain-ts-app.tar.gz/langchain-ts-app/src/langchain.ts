import * as dotenv from "dotenv";
import { ChatGoogleGenerativeAI } from "@langchain/google-genai";
import { PromptTemplate } from "@langchain/core/prompts";
import { LangChainTracer } from "@langchain/core/tracers/tracer_langchain";

dotenv.config();

const GEMINI_API_KEY = process.env.GEMINI_API_KEY;

if (!GEMINI_API_KEY) {
    throw new Error("Missing Google Gemini API Key");
}

const GEMINI_MODEL = process.env.GEMINI_MODEL;

if (!GEMINI_MODEL) {
    throw new Error("Missing Google Gemini Model");
}

// Create an Google Gemini LLM client instance
const llm = new ChatGoogleGenerativeAI({
    model: GEMINI_MODEL,
    maxOutputTokens: 2048,
    apiKey: GEMINI_API_KEY,
});

// Define a prompt template
const promptTemplate
 = new PromptTemplate({
    inputVariables: ["question"],
    template: "Answer the following question: {question}",
});

const tracer = new LangChainTracer({
    projectName: "langchain-ts-app"
});

// Define the LLM fetch request function
export const fetchRequest = async (text: string) => {

    // Replace the 'question' placeholder with the actual question
    const formattedPrompt = await promptTemplate.format({
        question: text,
    });

    // Execute the prompt
    return await llm.invoke(
        formattedPrompt,
        { callbacks: [tracer] }
    );
};