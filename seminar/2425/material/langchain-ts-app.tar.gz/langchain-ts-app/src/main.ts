import { fetchRequest } from "./langchain";

const main = async () => {
  const question = "Tell me a joke.";
  const response = await fetchRequest(question);
  console.log("Response:", response.content);
};

main().catch((err) => {
  console.error("Error:", err);
});